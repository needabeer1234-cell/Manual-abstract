import { connectAtlas } from "./atlas/openProtocol";

const ATLAS_IP = "192.168.0.10";
const ATLAS_PORT = 4545;

console.log("Backend boot OK");

connectAtlas(ATLAS_IP, ATLAS_PORT);
