import net from "net";

export function connectAtlas(ip: string, port: number) {
  const socket = new net.Socket();

  socket.connect(port, ip, () => {
    console.log(`✅ Connected to Atlas ${ip}:${port}`);

    // Open Protocol HELLO (MID 0001)
    const hello = "00200001001\r\n";
    console.log("📤 TX:", JSON.stringify(hello));

    socket.write(hello);
  });

  socket.on("data", (data: Buffer) => {
    console.log("📩 RX:", data.toString("utf8"));
  });

  socket.on("error", (err) => {
    console.error("❌ Atlas TCP Error:", err.message);
  });

  socket.on("close", () => {
    console.log("🔌 Atlas connection closed");
  });
}
